const express = require('express');
const router = express.Router();

// POST request to create a new note (just a dummy route for now)
router.post('/create', (req, res) => {
  res.json({ message: 'Note created successfully' });
});

module.exports = router;
